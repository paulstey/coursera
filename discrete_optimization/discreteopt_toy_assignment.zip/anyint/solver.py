#!/usr/bin/python
# -*- coding: utf-8 -*-

def solve_it(input_data):
    # return an integer that is the number of points you would like to get
    return '0'

if __name__ == '__main__':
    print('This script submits the integer: %s\n' % solve_it(''))

